package com.task.reconeyez;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReconeyezApplicationTests {

	@Test
	void contextLoads() {
	}

}
