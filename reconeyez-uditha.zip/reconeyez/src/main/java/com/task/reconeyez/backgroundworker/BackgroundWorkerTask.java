package com.task.reconeyez.backgroundworker;


import com.task.reconeyez.controller.DevicesController;
import com.task.reconeyez.service.DevicesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Component
@PropertySource("classpath:application.properties")
public class BackgroundWorkerTask {

    private static Logger LOGGER = LoggerFactory.getLogger(BackgroundWorkerTask.class);

    @Autowired
    private DevicesService devicesService;

    @Value( "${upload.file.path}" )
    public String uploadFilePath;

    @Scheduled(fixedRate = 2000)
    public void scheduledUpdateJob(){

        List<List<String>> records = new ArrayList<>();

        try {
            LOGGER.info("Fixed Delay Task :: Execution Time - {}", new Date().getTime());
            TimeUnit.SECONDS.sleep(5);


            InputStream inputStream = this.getClass().getResourceAsStream(uploadFilePath);
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader br = new BufferedReader(inputStreamReader);
                String line;
                while ((line = br.readLine()) != null) {
                    String[] values = line.split(",");
                    records.add(Arrays.asList(values));
                    devicesService.updateDevice(values[0],values[1]);
                }




        } catch (InterruptedException ex) {
            LOGGER.error("Ran into an error {}", ex);
            throw new IllegalStateException(ex);
        } catch (FileNotFoundException e) {
            LOGGER.error("Ran into an error {}", e);
        } catch (IOException e) {
            LOGGER.error("Ran into an error {}", e);
        }

    }

}
