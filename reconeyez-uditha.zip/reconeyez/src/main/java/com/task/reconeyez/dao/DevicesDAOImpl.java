package com.task.reconeyez.dao;

import com.task.reconeyez.domain.Device;
import com.task.reconeyez.service.DevicesServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
public class DevicesDAOImpl implements DevicesDAO{

    private static Logger LOGGER = LoggerFactory.getLogger(DevicesDAOImpl.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Device> getDeviceInfor(String shortId) {

        List<Device> devices=null;
        try{
            String sql = "SELECT  device_guid, last_modified_date, customer, updated_throgh_external from devices WHERE device_guid LIKE '%"+shortId+"%' ";

            devices = jdbcTemplate.query(
                    sql,
                    new DeviceRowMapper());
        }catch (Exception e){
            LOGGER.error(e.getMessage());
        }

        return devices;
    }

    @Override
    public Device createDeviceInfor(String device_guid) {
        Device device = new Device();
        try{

            Date current = new Date();
            device.setDevice_guid(device_guid);
            device.setLast_modified_date(current);
            String sql = "INSERT INTO devices (device_guid, last_modified_date) VALUES ("
                    + "'"+device_guid+"', '"+ new Date() +"')";

            int rows = jdbcTemplate.update(sql);
            if (rows > 0) {
                System.out.println("A new row has been inserted.");
            }
        }catch (Exception e){
            LOGGER.error(e.getMessage());
        }
        return device;
    }

    @Override
    public Device updateDeviceInfor(String device_guid, String customer) {
        try{
            String sql = "UPDATE devices SET customer = '"+customer+"' , last_modified_date= '"+ new Date() +"' WHERE device_guid = '"+device_guid+"' ";

            jdbcTemplate.update(sql);
        }catch (Exception e){
            LOGGER.error(e.getMessage());
        }
        return null;
    }

    @Override
    public void deleteDeviceInfor(String device_guid) {
        try{
            String sql = "DELETE from devices WHERE device_guid = '"+device_guid+"' ";

            jdbcTemplate.update(sql);
        }catch (Exception e){
            LOGGER.error(e.getMessage());
        }
    }

}
