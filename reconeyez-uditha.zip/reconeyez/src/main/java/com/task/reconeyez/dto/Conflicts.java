package com.task.reconeyez.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Date;

public class Conflicts {

    private String guid;
    private Date seen;
    private Boolean external;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String customer;

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public Date getSeen() {
        return seen;
    }

    public void setSeen(Date seen) {
        this.seen = seen;
    }

    public Boolean getExternal() {
        return external;
    }

    public void setExternal(Boolean external) {
        this.external = external;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }
}
