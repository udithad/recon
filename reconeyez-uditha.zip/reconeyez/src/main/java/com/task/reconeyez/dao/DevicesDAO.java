package com.task.reconeyez.dao;

import com.task.reconeyez.domain.Device;

import java.util.List;

public interface DevicesDAO {
    public List<Device> getDeviceInfor(String shortId);
    public Device createDeviceInfor(String device_guid);
    public Device updateDeviceInfor(String device_guid,String customer);
    public void deleteDeviceInfor(String device_guid);
}
