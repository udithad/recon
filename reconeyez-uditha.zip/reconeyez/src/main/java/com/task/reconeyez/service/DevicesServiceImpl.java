package com.task.reconeyez.service;

import com.task.reconeyez.dao.DevicesDAO;
import com.task.reconeyez.domain.Device;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DevicesServiceImpl implements DevicesService{

    private static Logger LOGGER = LoggerFactory.getLogger(DevicesServiceImpl.class);

    private DevicesDAO devicesDAO;

    public DevicesServiceImpl(DevicesDAO devicesDAO) {
        this.devicesDAO = devicesDAO;
    }

    @Override
    public Device getDeviceInfor(String guid) {


        String shortId = getShortId(guid);

        List<Device> deviceList = devicesDAO.getDeviceInfor(shortId);

        Device device = new Device();
        device.setDevice_guid(guid);
        device.setConflicting_devices(deviceList);

        return device;
    }

    private String getShortId(String device_guid){
        String shortId= null;
        if(device_guid != null){
            shortId = device_guid.substring(2,6);
        }
        return shortId;
    }

    @Override
    public Device createDeviceInfor(String guid) {
        return devicesDAO.createDeviceInfor(guid);
    }

    @Override
    public void deleteDeviceInfor(String guid) {
         devicesDAO.deleteDeviceInfor(guid);
    }

    @Override
    public Device updateDevice(String guid, String customer) {
        return devicesDAO.updateDeviceInfor(guid,customer);
    }
}
