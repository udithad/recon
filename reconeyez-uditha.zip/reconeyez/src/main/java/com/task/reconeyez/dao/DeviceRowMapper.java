package com.task.reconeyez.dao;


import org.springframework.jdbc.core.RowMapper;
import com.task.reconeyez.domain.Device;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DeviceRowMapper implements RowMapper<Device> {
    @Override
    public Device mapRow(ResultSet rs, int rowNum) throws SQLException {

        Device device = new Device();
        device.setDevice_guid(rs.getString("device_guid"));
        device.setLast_modified_date(rs.getDate("last_modified_date"));
        if(rs.getString("customer") != null)
        device.setCustomer(rs.getString("customer"));
        device.setUpdated_throgh_external(rs.getBoolean("updated_throgh_external"));

        return device;
    }
}
