package com.task.reconeyez.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;

public class DeviceDTO {

    private String providedGUID;
    private List<Conflicts> conflicts;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String external;

    public String getProvidedGUID() {
        return providedGUID;
    }

    public void setProvidedGUID(String providedGUID) {
        this.providedGUID = providedGUID;
    }

    public List<Conflicts> getConflicts() {
        return conflicts;
    }

    public void setConflicts(List<Conflicts> conflicts) {
        this.conflicts = conflicts;
    }

    public String getExternal() {
        return external;
    }

    public void setExternal(String external) {
        this.external = external;
    }
}
