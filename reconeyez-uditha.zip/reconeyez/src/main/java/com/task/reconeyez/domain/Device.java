package com.task.reconeyez.domain;

import com.task.reconeyez.dto.Conflicts;

import java.util.Date;
import java.util.List;

public class Device {

    private Integer id;
    private String device_guid;
    private Date last_modified_date;
    private List<Device> conflicting_devices;
    private String customer;
    private Boolean updated_throgh_external;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDevice_guid() {
        return device_guid;
    }

    public void setDevice_guid(String device_guid) {
        this.device_guid = device_guid;
    }

    public Date getLast_modified_date() {
        return last_modified_date;
    }

    public void setLast_modified_date(Date last_modified_date) {
        this.last_modified_date = last_modified_date;
    }

    public List<Device> getConflicting_devices() {
        return conflicting_devices;
    }

    public void setConflicting_devices(List<Device> conflicting_devices) {
        this.conflicting_devices = conflicting_devices;
    }

    public Boolean getUpdated_throgh_external() {
        return updated_throgh_external;
    }

    public void setUpdated_throgh_external(Boolean updated_throgh_external) {
        this.updated_throgh_external = updated_throgh_external;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }
}
