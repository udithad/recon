package com.task.reconeyez.controller;

import com.task.reconeyez.domain.Device;
import com.task.reconeyez.dto.Conflicts;
import com.task.reconeyez.dto.DeviceDTO;

import java.util.ArrayList;

public class BaseController {

    protected DeviceDTO transformDevice(Device device){
        DeviceDTO deviceDTO = new DeviceDTO();
        deviceDTO.setProvidedGUID(device.getDevice_guid());

        if(device.getConflicting_devices() != null) {
            device.getConflicting_devices().stream().forEach(dev -> {
                Conflicts conflict = new Conflicts();
                conflict.setExternal(dev.getUpdated_throgh_external());
                conflict.setGuid(dev.getDevice_guid());
                conflict.setSeen(dev.getLast_modified_date());
                conflict.setCustomer(dev.getCustomer());
                if (deviceDTO.getConflicts() == null) {
                    deviceDTO.setConflicts(new ArrayList<>());
                }
                deviceDTO.getConflicts().add(conflict);
            });
        }else{
            deviceDTO.setConflicts(new ArrayList<>());
            deviceDTO.setExternal("false");
        }

        return deviceDTO;
    }

}
