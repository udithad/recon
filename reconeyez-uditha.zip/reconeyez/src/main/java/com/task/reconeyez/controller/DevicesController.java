package com.task.reconeyez.controller;

import com.task.reconeyez.dto.Conflicts;
import com.task.reconeyez.domain.Device;
import com.task.reconeyez.dto.DeviceDTO;
import com.task.reconeyez.service.DevicesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;


@Controller
@RequestMapping("devices")
public class DevicesController extends BaseController {

    private static Logger LOGGER = LoggerFactory.getLogger(DevicesController.class);

    private DevicesService devicesService;

    public DevicesController(DevicesService devicesService) {
        this.devicesService = devicesService;
    }

    @RequestMapping(value = "/{guid}",method = RequestMethod.GET)
    public @ResponseBody
    DeviceDTO getConflictingDevices(@PathVariable("guid") @NotNull String guid){
        LOGGER.info("Get Request received with GUID : "+ guid);
        Device device = devicesService.getDeviceInfor(guid);
        return transformDevice(device);
    }

    @RequestMapping(value = "/{guid}",method = RequestMethod.POST)
    public @ResponseBody
    DeviceDTO createDevices(@PathVariable("guid") @NotNull String guid){
        LOGGER.info("Create Device Request received with GUID : "+ guid);
        Device device = devicesService.createDeviceInfor(guid);
        return transformDevice(device);
    }

    @RequestMapping(value = "/{guid}",method = RequestMethod.DELETE)
    public @ResponseBody
    DeviceDTO deleteDevices(@PathVariable("guid") @NotNull String guid){
        LOGGER.info("Delete Device Request received with GUID : "+ guid);
         devicesService.deleteDeviceInfor(guid);
         return new DeviceDTO();
    }

}
