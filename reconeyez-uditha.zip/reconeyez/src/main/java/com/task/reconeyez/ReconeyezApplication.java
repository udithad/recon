package com.task.reconeyez;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;


@SpringBootApplication
@EnableScheduling
public class ReconeyezApplication {



	public static void main(String[] args) {
		SpringApplication.run(ReconeyezApplication.class, args);
	}

}
