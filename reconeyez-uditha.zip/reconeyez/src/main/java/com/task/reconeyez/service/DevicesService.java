package com.task.reconeyez.service;


import com.task.reconeyez.domain.Device;

public interface DevicesService {
    public Device getDeviceInfor(String guid);
    public Device createDeviceInfor(String guid);
    public void deleteDeviceInfor(String guid);
    public Device updateDevice(String guid,String customer);
}
