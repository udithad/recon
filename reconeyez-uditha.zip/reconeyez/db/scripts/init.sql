\c reconeyez

CREATE TABLE devices (
  id  SERIAL PRIMARY KEY,
  device_guid VARCHAR(18) NOT NULL,
  customer VARCHAR (20),
  updated_throgh_external BOOL DEFAULT 'f',
  last_modified_date timestamp NOT NULL);